import requests
import playsound
import os
yvyin=dict()
def tts(text):
	save(text,"./hello.mp3")
	play("./hello.mp3")
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
def save(text,filepath):
	r=requests.get("https://fanyi.qq.com/api/tts?platform=PC_Website&lang=zh&text=%s&guid=d152fbef-fdd7-4f50-ad8b-2553cb5ecee6"%text)
	with open(filepath,"wb") as f:
		f.write(r.content)
#tts("你好世界！Hello World！")
