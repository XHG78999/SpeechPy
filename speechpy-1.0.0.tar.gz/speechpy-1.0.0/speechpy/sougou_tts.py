#-*- coding:gbk -*-
import requests
import os
import playsound
yvyin=dict()
def tts(text):
	save(text,"./hello.mp3",2)
	play("./hello.mp3")
def save(text,filepath,speed=1):
	r=requests.get("https://fanyi.sogou.com/reventondc/synthesis?text=%s&speed=%s&lang=zh-CN&from=translateweb"%(text,speed))
	with open(filepath,"wb") as f:
		f.write(r.content)
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
#tts("���")
