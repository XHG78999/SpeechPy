import random
import requests
import playsound
import os
yvyin={
"度小宇（普通男声）":2,
"度小美（普通女声）":1,
"度逍遥（情感男声）":3,
"度丫丫（情感女声）":4,
"度博文（精品音库情感男声）":106,
"度米朵（精品音库女童声）":103,
"度小童（精品音库男童声）":110,
"度小萌（精品音库情感女声）":111,
"度小娇（精品音库情感女声）":5
}
def tts(text,per=5,spd=5,pit=103,vol=50):
	save(text,"./hello.mp3",per=per,spd=spd,pit=pit,vol=vol)
	play("./hello.mp3")
def play(mp3_url):
	playsound.playsound(mp3_url)
	os.remove(mp3_url)
def save(text,filepath,per=103,spd=5,pit=5,vol=50):
	'''USAGE：
	利用AI接口tts.baidu.com语音合成并保存MP3，不需要APP_ID等标识
	text：要转换的文字，必选参数。
	filepath：保存位置，必选参数。
	pit：语速，默认值5。
	vol：音量，默认值50。
	per：发音人，默认值103（度米朵），各语音代号请查看变量yvyin
	'''
	headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)Chrome/62.0.3202.94 Safari/537.36'}
	baidu_api_url = "http://tts.baidu.com/text2audio"
	baidu_api_set = {"idx": 1, "cuid": "baidu_speech_demo", "cod": 1,"lan": "zh", "ctp": 1, "pdt": 1, "spd": spd, "per":per, "vol": vol, "pit": pit}
	api_url = '{11}?idx={0}&tex={1}&cuid={2}&cod={3}&lan={4}&ctp={5}&pdt={6}&spd={7}&per={8}&vol={9}&pit={10}'\
		.format(baidu_api_set["idx"], text, baidu_api_set["cuid"], baidu_api_set["cod"], baidu_api_set["lan"],
				baidu_api_set["ctp"], baidu_api_set["pdt"], baidu_api_set["spd"], baidu_api_set["per"],
				baidu_api_set["vol"], baidu_api_set["pit"], baidu_api_url)
	res = requests.get(api_url, headers=headers)
	with open(filepath, 'wb') as f:
		f.write(res.content)
#test
#tts("Hello World!")
#tts("说中国话。你好世界！",per=4)
