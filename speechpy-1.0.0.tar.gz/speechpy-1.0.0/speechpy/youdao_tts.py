import requests
import playsound
import os
yvyin=dict()
def tts(text):
	save(text,"./hello.mp3")
	play("./hello.mp3")
def save(text,filepath):
	r=requests.get("http://dict.youdao.com/dictvoice?audio=%s"%text)
	with open(filepath,"wb") as f:
		f.write(r.content)
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
#tts("Hello")
