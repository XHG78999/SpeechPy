import requests
import playsound
import os
yvyin={
"女声小静":"xjingf",
"女声小兰":"gqlanf",
"女声晶晶":"jjingfp",
"女声芳芳":"gdfanfp",
"女声风吟":"feyinf",
"女声小妖":"xiyaof",
"女声小佚":"anony",
"男童连连（精品版）":"lzliafp",
"男童连连":"lzliaf",
"男童连连（标准版）":"lzliafa",
"男童方方":"gdfanf_boy",
"男童堂堂":"boy",
"男声小军（精品版）":"xijunma",
"男声小俞":"yukaim_all",
"男声纲叔":"gdgm",
"男声小军":"xijunm",
"男声考拉":"kaolam",
"男声秋木":"qiumum",
"男声小睿":"tzruim",
"女童然然（标准版）":"qianranfa",
"女童佚伕":"anonyg",
"女童然然":"qianranf"
}
def tts(text,per="xjingf"):
	save(text,"./hello.mp3",per)
	play("./hello.mp3")
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
def save(text,filepath,per="xjingf"):
	r=requests.get("https://dds.dui.ai/runtime/v1/synthesize?voiceId=%s&text=%s&speed=1&volume=100&audioType=mp3&mp3Quanlity=high"%(per,text))
	with open(filepath,"wb") as f:
		f.write(r.content)
#tts("你好世界！Hello World！")
#tts("滚蛋滚蛋滚蛋！",per="boy")
