import requests
import playsound
import os
def tts(text,per=0):
	save(text,"./hello.mp3",per)
	play("./hello.mp3")
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
def save(text,filepath,per):
	r=requests.get("https://neuhubdemo.jd.com/api/tts/stream?reqid=bfb09237-4864-442c-bfde-f59cceba3899&text=%s&tim=%s&sp=1"%(text,per))
	with open(filepath,"wb") as f:
		f.write(r.content)
#tts("你好世界！Hello World！")
#tts("你好世界！Hello World！",1)
