import requests
import playsound
import os
yvyin=dict()
def tts(text,spe=0,pit=0,vol=0):
	save(text,"./hello.mp3",spe,pit,vol)
	play("./hello.mp3")
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
def save(text,filepath,spe=0,pit=0,vol=0):
	r=requests.get("http://120.24.87.124/cgi-bin/ekho2.pl?cmd=SAVEMP3&voice=iflytek&speedDelta=%s&pitchDelta=%s&volumeDelta=%s&text=%s"%(spe,pit,vol,text))
	with open(filepath,"wb") as f:
		f.write(r.content)
#tts("你好世界！Hello World！")
