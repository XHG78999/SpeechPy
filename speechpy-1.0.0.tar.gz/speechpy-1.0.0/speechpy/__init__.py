__doc__='''

                      PyWebSpeech-一个通过爬虫系统实现朗读的系统

优点：
1.简洁方便。依赖库极少（仅requests和playsound）
2.支持多个API。
有腾讯，京东，思必驰，微软，Ekho（简体及粤语），讯飞（简体及粤语），谷歌，搜狗等API，且不需要API秘钥
（这对于某些人来说是很有用的，就像思必驰，你还要打电话申请API，烦不？）
----------------不怎么华丽的分割线----------------
注意事项：
1.在使用时，建议使用百度TTS（baidu_tts.tts("XXX")）。
2.使用时需联网，否则会报连try-except都搞不了的错误。（socket.XXXError和urllib.XXXError，还有requests.XXXError，连环错误，根本Except不来）
3.有道服务（youdao_tts.tts("XXXXXX")）仅支持英文！！！！！！
有道服务（youdao_tts.tts("XXXXXX")）仅支持英文！！！！！！
有道服务（youdao_tts.tts("XXXXXX")）仅支持英文！！！！！！
（重要的事情说三遍）
4.如出现错误UnicodeDecodeError（由playsound引发），请将playsound模块的头部
______________________________________
|1| # -*- coding:utf-8 -*-
______________________________________
修改为
______________________________________
|1| # -*- coding:gbk -*-
______________________________________
即可。这是Windows下的编码错误，因为Windows使用GBK编码，而Python使用UTF-8编码，就会出错。
如仍然出错，请调整语音参数。
感谢使用！
'''

