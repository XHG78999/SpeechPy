import requests
import playsound
import os
yvyin=dict()
def tts(text):
	save(text,"./hello.mp3")
	play("./hello.mp3")
def play(sound):
	playsound.playsound(sound)
	os.remove(sound)
def save(text,filepath):
	r=requests.get("http://api.microsofttranslator.com/V2/Http.svc/Speak?language=zh-cn&appid=05DBC69E5594C137B9E22680F92F8E5E12C6F663&text=%s&format=audio/mp3&options=MaxQuality"%text)
	with open(filepath,"wb") as f:
		f.write(r.content)
#tts("你好世界！Hello World！")
